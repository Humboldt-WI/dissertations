from setuptools import setup

setup(name='cat',
      version='0.1',
      description='CAt (Contrastive Attention): Embarrassingly Simple Unsupervised Aspect Extraction',
      url='https://github.com/clips/cat',
      author='Stéphan Tulkens, Andreas van Cranenburgh',
      author_email='stephan.tulkens@uantwerpen.be, a.w.van.cranenburgh@rug.nl',
      license='GPL-3.0',
      packages=['cat'],
      install_requires=[
          'numpy',
          'gensim',
          'tqdm',
          'reach',
          'matplotlib',
          'pandas',
          'pyconll',
          'scikit_learn'
      ],
      zip_safe=False
      )
